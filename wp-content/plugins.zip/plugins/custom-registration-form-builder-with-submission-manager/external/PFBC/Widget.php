<?php

interface Widget {
    
}