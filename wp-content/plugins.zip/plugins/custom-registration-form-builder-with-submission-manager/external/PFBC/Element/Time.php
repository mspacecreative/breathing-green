<?php
class Element_Time extends Element_Textbox {
	protected $_attributes = array("type" => "time");
}
