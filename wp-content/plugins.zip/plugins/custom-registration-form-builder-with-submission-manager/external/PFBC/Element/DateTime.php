<?php
class Element_DateTime extends Element_Textbox {
	protected $_attributes = array("type" => "datetime");
}
