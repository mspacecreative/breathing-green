<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$form = new RM_PFBC_Form("add-field");

$form->configure(array(
    "prevent" => array("bootstrap", "jQuery"),
    "action" => ""
));

$form->addElement(new Element_HTML('<div class="rmheader">' . RM_UI_Strings::get("TITLE_EDIT_FIELD_PAGE") . '</div>'));

$form->addElement(new Element_Hidden("field_id", $data->model->field_id));

$form->addElement(new Element_Hidden("form_id", $data->form_id));
$form->addElement(new Element_Hidden("field_is_required", 1));

if(!empty($data->model->field_type) && strtolower($data->model->field_type)=='username'){
    $form->addElement(new Element_Textbox("<b>" . RM_UI_Strings::get('LABEL_SELECT_TYPE') . "</b>", "primary_field_type", array("id" => "rm_field_type_select_dropdown", "disabled" => "1" , "value" => $data->model->field_type, "class" => "rm_static_field rm_required", /*"required" => "1",*/ "longDesc"=>'This is Username field. Type of this field can not be changed.')));
}
else if(!empty($data->model->field_type) && strtolower($data->model->field_type)=='userpassword'){
    $form->addElement(new Element_Textbox("<b>" . RM_UI_Strings::get('LABEL_SELECT_TYPE') . "</b>", "primary_field_type", array("id" => "rm_field_type_select_dropdown", "disabled" => "1" , "value" => $data->model->field_type, "class" => "rm_static_field rm_required", /*"required" => "1",*/ "longDesc"=>'This is password field. Type of this field can not be changed.')));
}
else{
    $form->addElement(new Element_Textbox("<b>" . RM_UI_Strings::get('LABEL_SELECT_TYPE') . "</b>", "primary_field_type", array("id" => "rm_field_type_select_dropdown", "disabled" => "1" , "value" => $data->model->field_type, "class" => "rm_static_field rm_required", /*"required" => "1",*/ "longDesc"=>RM_UI_Strings::get('HELP_ADD_PRIMARY_FIELD_EMAIL'))));
}

$form->addElement(new Element_Hidden('field_type',$data->model->field_type));
$form->addElement(new Element_Textbox("<b>" . RM_UI_Strings::get('LABEL_LABEL') . "</b>", "field_label", array("class" => "rm_static_field rm_required", "required" => "1", "value" => $data->model->field_label, "longDesc"=>RM_UI_Strings::get('HELP_ADD_FIELD_LABEL'))));
$form->addElement(new Element_Textbox("<b>" . RM_UI_Strings::get('LABEL_PLACEHOLDER_TEXT') . "</b>", "field_placeholder", array("id" => "rm_field_placeholder", "class" => "rm_static_field rm_text_type_field rm_input_type", "value" => $data->model->field_options->field_placeholder, "longDesc"=>RM_UI_Strings::get('HELP_ADD_FIELD_PLACEHOLDER'))));

$form->addElement(new Element_HTML('<div id="rm_field_helptext_container">'));
$form->addElement(new Element_Textarea("<b>" . RM_UI_Strings::get('LABEL_HELP_TEXT') . "</b>", "help_text", array("id" => "rm_field_helptext", "class" => "", "value" => $data->model->field_options->help_text, "longDesc" => RM_UI_Strings::get('HELP_ADD_FIELD_HELP_TEXT'))));
$form->addElement(new Element_HTML('</div>'));

/***Begin :Icon Settings******/
$form->addElement(new Element_HTML('<div class="rmrow rm_field_settings_group_header rm_icon_sett_collapsed" id="rm_icon_field_settings_header" onclick="rm_toggle_icon_settings()"><a>' . RM_UI_Strings::get('ICON_FIELD_SETTINGS') . '<span class="rm-toggle-settings"></span></a></div>'));
$form->addElement(new Element_HTML('<div id="rm_icon_field_settings_container" style="display:none">'));
$form->addElement(new Element_HTML('<div id="rm_icon_setting_container">'));
$form->addElement(new Element_HTML('<div class="rmrow" id="rm_jqnotice_row_date_type"><div class="rmfield" for="rm_field_value_options_textarea"><label>'.RM_UI_Strings::get('LABEL_FIELD_ICON').'</label></div><div class="rminput" id="rm_field_icon_chosen"><i class="material-icons"'.$icon_style.' id="id_show_selected_icon">'.$f_icon->codepoint.'</i><div class="rm-icon-action"><div onclick="show_icon_reservoir()"><a href="javascript:void(0)">'.RM_UI_Strings::get('LABEL_FIELD_ICON_CHANGE').'</a></div> <div onclick="rm_remove_icon()"><a href="javascript:void(0)">'.RM_UI_Strings::get('LABEL_REMOVE').'</a></div></div></div><div class="rmnote"><div class="rmprenote"></div><div class="rmnotecontent">'.RM_UI_Strings::get('HELP_FIELD_ICON').'</div></div></div>'));
$form->addElement(new Element_Hidden('input_selected_icon_codepoint', $f_icon->codepoint, array('id'=>'id_input_selected_icon')));
$form->addElement(new Element_Color(RM_UI_Strings::get('LABEL_FIELD_ICON_FG_COLOR'), "icon_fg_color", array("id" => "rm_", "value" => $f_icon->fg_color, "onchange" => "change_icon_fg_color(this)", "longDesc" => RM_UI_Strings::get('HELP_FIELD_ICON_FG_COLOR'))));

$form->addElement(new Element_Color(RM_UI_Strings::get('LABEL_FIELD_ICON_BG_COLOR'), "icon_bg_color", array("id" => "rm_", "value" => $f_icon->bg_color, "onchange" => "change_icon_bg_color(this)", "longDesc" => RM_UI_Strings::get('HELP_FIELD_ICON_BG_COLOR'))));

$form->addElement(new Element_Range(RM_UI_Strings::get('LABEL_FIELD_ICON_BG_ALPHA'), "icon_bg_alpha", array("id" => "rm_", "value" => $f_icon->bg_alpha, "step" => 0.1, "min" => 0, "max" => 1, "oninput" => "finechange_icon_bg_color()", "onchange" => "finechange_icon_bg_color()", "longDesc" => RM_UI_Strings::get('HELP_FIELD_ICON_BG_ALPHA'))));

$form->addElement(new Element_Select(RM_UI_Strings::get('LABEL_FIELD_ICON_SHAPE'), "icon_shape", $icon_shapes, array("id" => "rm_", "value" => $f_icon->shape, "onchange" => "change_icon_shape(this)", "longDesc" => RM_UI_Strings::get('HELP_FIELD_ICON_SHAPE'))));
$form->addElement(new Element_HTML('</div>'));
$form->addElement(new Element_HTML('</div>'));
/***END :Icon Settings******/

$form->addElement(new Element_HTML('<div style="display:none">'));
$form->addElement(new Element_jQueryUIDate("", '', array()));
$form->addElement(new Element_HTML('</div>'));

/**** Begin: Advanced Field Settings ****/
$form->addElement(new Element_HTML('<div class="rmrow rm_field_settings_group_header rm_adv_sett_collapsed" id="rm_advance_field_settings_header" onclick="rm_toggle_adv_settings()"><a>' . RM_UI_Strings::get('ADV_FIELD_SETTINGS') . '<span class="rm-toggle-settings"></span></a></div>'));
$form->addElement(new Element_HTML('<div id="rm_advance_field_settings_container" style="display:none">'));
$form->addElement(new Element_Textbox("<b>" . RM_UI_Strings::get('LABEL_CSS_CLASS') . "</b>", "field_css_class", array("id" => "rm_field_class", "class" => "rm_static_field rm_required", "value" => $data->model->field_options->field_css_class, "longDesc"=>RM_UI_Strings::get('HELP_ADD_FIELD_CSS_CLASS'))));

if(strtolower($data->model->field_type)=="username" || strtolower($data->selected_field)=='username'){
    $form->addElement(new Element_Textarea("<b>Username exists error</b>", "user_exists_error", array("class" => "", "value" =>$data->model->field_options->user_exists_error , "longDesc" => 'Contents of the error message user sees when trying to register with existing or blacklisted/ reserved username. You can manage blacklisted/ reserved usernames in Global Settings → Security')));
    $form->addElement(new Element_Checkbox("<b>Allowed Characters</b>", "username_characters", array('alphabets' => "Alphabets",'numbers'=>'Numbers','underscores'=>'Underscores','periods'=>'Periods'), array("class" => "rm_field_multiline rm_input_type", "value" => $data->model->field_options->username_characters, "longDesc"=>'Select the type of characters accepted for usernames. If none selected, All the characters would be allowed.')));
    $form->addElement(new Element_Textarea("<b>Invalid username format error</b>", "invalid_username_format", array("class" => "", "value" => $data->model->field_options->invalid_username_format, "longDesc" => 'Contents of the error message user sees when trying to enter username with characters not allowed. Use code {{allowed_characters}} to insert allowed characters dynamically.')));
}

if(strtolower($data->model->field_type)=="userpassword" || strtolower($data->selected_field)=='userpassword'){
    $form->addElement(new Element_Checkbox("<b>Display password confirmation field</b>", "en_confirm_pwd", array('1'=>''), array("class" => "rm_field_multiline rm_input_type en_confirm_pwd", "value" => $data->model->field_options->en_confirm_pwd, "longDesc"=>'Display a password confirmation field below the password field.')));
        $form->addElement(new Element_HTML('<div class="childfieldsrow" id="confirm_pwd_options">'));
             $form->addElement(new Element_Textarea("<b>Password mismatch error</b>", "pass_mismatch_err", array("class" => "", "value" =>$data->model->field_options->pass_mismatch_err , "longDesc" => 'Contents of the error message user sees when the password entered in password confirmation field does not matches.')));
        $form->addElement(new Element_HTML('</div>'));
    $gopts= new RM_Options();
 

      
    $form->addElement(new Element_Checkbox("<b>Display password strength meter</b>", "en_pass_strength", array('1'=>''), array("class" => "rm_field_multiline rm_input_type en_pass_strength ", "value" => $data->model->field_options->en_pass_strength, "longDesc"=>'Displays a live password strength meter to provide feedback to the user about the strength of the password they are entering. For advance password rules, checkout Global Settings → Security.')));   
    $form->addElement(new Element_HTML("<div class='childfieldsrow' id='pwd_strength_options'>"));
        $form->addElement(new Element_Textbox("<b>Short</b>", "pwd_short_msg", array("class" => "rm_static_field", "value" => $data->model->field_options->pwd_short_msg, "longDesc"=>'')));
        $form->addElement(new Element_Textbox("<b>Weak</b>", "pwd_weak_msg", array("class" => "rm_static_field", "value" => $data->model->field_options->pwd_weak_msg, "longDesc"=>'')));
        $form->addElement(new Element_Textbox("<b>Short</b>", "pwd_medium_msg", array("class" => "rm_static_field", "value" => $data->model->field_options->pwd_medium_msg, "longDesc"=>'')));
        $form->addElement(new Element_Textbox("<b>Short</b>", "pwd_strong_msg", array("class" => "rm_static_field", "value" => $data->model->field_options->pwd_strong_msg, "longDesc"=>'')));
    $form->addElement(new Element_HTML('</div>')); 
     
      
}
$form->addElement(new Element_HTML('</div>'));
/**** End: Advanced Field Settings */

//Button Area
$form->addElement(new Element_HTMLL('&#8592; &nbsp; Cancel', '?page=rm_field_manage&rm_form_id='.$data->form_id, array('class' => 'cancel')));
$form->addElement(new Element_Button(RM_UI_Strings::get('LABEL_SAVE'), "submit", array("id" => "rm_submit_btn", "class" => "rm_btn", "name" => "submit")));

?>

<?php 

$form->render();
