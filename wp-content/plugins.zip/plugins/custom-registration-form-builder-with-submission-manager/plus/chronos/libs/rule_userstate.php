<?php

class RM_Chronos_Rule_UserState extends RM_Chronos_Rule_Abstract {
    
    public function get_type() {
        return RM_Chronos_Rule_Interface::RULE_TYPE_USER_STATE;
    }            
}


